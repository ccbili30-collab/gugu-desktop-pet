"""Create desktop shortcut for Gugupet control panel.

Called by install.bat. Uses VBS (always available on Windows).
Only creates ONE shortcut: the control panel (which can also launch the pet).
"""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DESKTOP = Path(os.path.expandvars("%USERPROFILE%")) / "Desktop"

# The shortcut points to the control panel .pyw — it launches the pet too
LNK_NAME = "咕咕桌宠.lnk"
LNK_TARGET_ARGS = "pet_control_panel.pyw"
LNK_DESC = "咕咕桌宠控制面板"


def _get_desktop() -> Path:
    """Try to get the real desktop path from the registry."""
    try:
        import winreg

        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders",
        )
        val, _ = winreg.QueryValueEx(key, "Desktop")
        winreg.CloseKey(key)
        expanded = os.path.expandvars(str(val))
        p = Path(expanded)
        if p.exists():
            return p
    except Exception:
        pass
    return DESKTOP


def _create_via_vbs(desktop: Path) -> bool:
    """Write a temp VBS and run it to create a .lnk shortcut."""
    # Use forward slashes in VBS strings to avoid escaping issues
    install_dir = str(ROOT).replace("\\", "/")
    lnk_path = str(desktop / LNK_NAME).replace("\\", "/")

    # Find pythonw.exe — resolve to absolute path for reliability
    pythonw = Path(sys.executable).parent / "pythonw.exe"
    if not pythonw.exists():
        pythonw = Path(sys.executable)  # fallback to python.exe
    pythonw_str = str(pythonw).replace("\\", "/")

    vbs = f"""Set Shell = CreateObject("WScript.Shell")
Set lnk = Shell.CreateShortcut("{lnk_path}")
lnk.TargetPath = "{pythonw_str}"
lnk.Arguments = "{LNK_TARGET_ARGS}"
lnk.WorkingDirectory = "{install_dir}"
lnk.Description = "{LNK_DESC}"
lnk.Save
"""
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".vbs", delete=False, encoding="utf-8"
    ) as f:
        f.write(vbs)
        vbs_path = f.name

    try:
        result = subprocess.run(
            ["cscript", "//nologo", vbs_path],
            capture_output=True,
            timeout=15,
        )
        return result.returncode == 0
    except Exception as e:
        print(f"  VBS error: {e}")
        return False
    finally:
        try:
            os.unlink(vbs_path)
        except Exception:
            pass


def main() -> int:
    desktop = _get_desktop()
    print(f"  桌面路径: {desktop}")

    ok = _create_via_vbs(desktop)

    if ok:
        print(f"  快捷方式已创建: {desktop / LNK_NAME}")
        return 0
    else:
        print("  快捷方式创建失败，请手动创建，指向:")
        print(f"    {ROOT / LNK_TARGET_ARGS}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
