"""Shared type aliases and constants for the brain layer.

Import from here to avoid circular imports between brain modules.
"""

from __future__ import annotations

from typing import Any

# Drive key names
DRIVE_ENERGY = "energy"
DRIVE_SOCIAL = "social"
DRIVE_CURIOSITY = "curiosity"
DRIVE_COMFORT = "comfort"
DRIVE_KEYS = (DRIVE_ENERGY, DRIVE_SOCIAL, DRIVE_CURIOSITY, DRIVE_COMFORT)

# Motive names
MOTIVE_REST = "rest"
MOTIVE_SEEK_ATTENTION = "seek_attention"
MOTIVE_EXPLORE_AIR = "explore_air"
MOTIVE_SETTLE = "settle"
ALL_MOTIVES = (MOTIVE_REST, MOTIVE_SEEK_ATTENTION, MOTIVE_EXPLORE_AIR, MOTIVE_SETTLE)

# Type aliases
DriveMap = dict[str, float]  # {"energy": 0.72, ...}
MemoryDict = dict[str, str]  # {"type": ..., "title": ..., "summary": ...}
ParamDict = dict[str, Any]  # intent params or event payload

# Event priority tiers
HIGH_PRIORITY_EVENTS = frozenset(
    {
        "user_message",
        "wall_hit",
        "ground_hit",
        "drag_release",
    }
)

LOW_PRIORITY_EVENTS = frozenset(
    {
        "owner_touch",
        "owner_pet",
        "owner_ping",
        "idle_tick",
        "state_tick",
    }
)
