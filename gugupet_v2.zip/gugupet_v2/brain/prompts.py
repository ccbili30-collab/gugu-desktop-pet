"""All prompt builders for gugupet_v2.

No side effects — pure string construction.
The brain calls these and passes results to llm_client.
"""

from __future__ import annotations

import json

from bridge.protocol import BrainInput, BodyEventName

_SYSTEM_PET = (
    "You are the built-in brain of a desktop pigeon pet. "
    "You speak in Chinese from the pet's perspective. "
    "You are playful, warm, and a little bird-brained. "
    "Never break character."
)

_SYSTEM_ACTION = (
    "You are the built-in brain of a desktop pigeon pet controlling its body. "
    "Reply ONLY with a compact JSON object. "
    "Do not add any text outside the JSON."
)

_ACTION_SCHEMA = (
    '{"reply":"<short Chinese pet utterance, may be empty>","intent":"<intent_name>",'
    '"params":<intent-specific JSON object>}'
)

_VALID_INTENTS = (
    "none reply_only react_pain react_joy react_surprise react_affection "
    "explore_air seek_attention approach_owner follow_owner rest settle go_sleep "
    "pose_change show_off emit_hearts"
)

_ACTION_RULES = (
    "Rules:\n"
    "- reply: what the pet says aloud. Keep it one short sentence or empty.\n"
    "- intent: choose the most fitting intent from the list.\n"
    f"- Valid intents: {_VALID_INTENTS}\n"
    '- params for pose_change: {"pose": "stand|idle|sit|peck|sleep"}\n'
    '- params for explore_air / seek_attention: {"hold_seconds": <float>}\n'
    '- params for follow_owner: {"duration": <seconds, max 8>}\n'
    '- params for approach_owner: {"hold_seconds": <float>}\n'
    '- params for show_off: {"shape": "circle|heart|figure8|spiral"}\n'
    '- params for emit_hearts: {"count": <int>}\n'
    '- params for rest / go_sleep: {"duration": <seconds>}\n'
    "- Use intent 'none' if no body action is needed.\n"
    "- If owner asks pet to fly/jump/move: use explore_air or show_off.\n"
    "- If owner asks pet to sit/sleep/rest: use pose_change or rest.\n"
    "- Only use follow_owner if owner explicitly asks pet to follow them.\n"
    "- Do NOT use placeholder replies like 收到啦.\n"
    "- Do NOT include stage directions or parenthetical descriptions.\n"
)


def _drives_line(drives: dict) -> str:
    parts = [f"{k}={v:.2f}" for k, v in drives.items()]
    return "Drives: " + ", ".join(parts)


def _body_line(bi: BrainInput) -> str:
    bs = bi.body_state
    return (
        f"Body state: {bs.pose}, facing={'right' if bs.facing >= 0 else 'left'}, "
        f"airborne={bs.airborne}, "
        f"pos=({bs.position_x:.0f},{bs.position_y:.0f}), "
        f"floor_y={bs.floor_y:.0f}, "
        f"work=({bs.work_left:.0f},{bs.work_top:.0f},{bs.work_right:.0f},{bs.work_bottom:.0f})"
    )


# ---------------------------------------------------------------------------
# Public prompt builders
# ---------------------------------------------------------------------------


def user_message_prompt(bi: BrainInput) -> tuple[str, str]:
    """Returns (system, user) for a user chat message."""
    mem = f"\nRelevant memory:\n{bi.memory_context}" if bi.memory_context else ""
    user = (
        f"Pet name: {bi.pet_name}\n"
        f"{_body_line(bi)}\n"
        f"{_drives_line(bi.drives)}\n"
        f"Emotion hint: {bi.emotion_hint}\n"
        f"{_ACTION_SCHEMA}\n"
        f"{_ACTION_RULES}"
        f"{mem}\n"
        f"Owner says: {bi.user_text}"
    )
    return _SYSTEM_ACTION, user


def body_event_prompt(bi: BrainInput) -> tuple[str, str] | None:
    """Returns (system, user) for a body signal event, or None if no prompt needed."""
    evt = bi.event
    p = evt.payload

    if evt.name == BodyEventName.OWNER_TOUCH:
        user = (
            f"Pet name: {bi.pet_name}. {_body_line(bi)}.\n"
            f"The owner just gently touched you with a single click.\n"
            f"Emotion hint: {bi.emotion_hint}. {_drives_line(bi.drives)}.\n"
            "Reply with exactly one short natural Chinese sentence from the pet's perspective."
        )
        return _SYSTEM_PET, user

    if evt.name == BodyEventName.OWNER_PET:
        user = (
            f"Pet name: {bi.pet_name}. {_body_line(bi)}.\n"
            f"The owner just petted you gently (right-click).\n"
            f"Emotion hint: {bi.emotion_hint}. {_drives_line(bi.drives)}.\n"
            "Reply with exactly one short natural Chinese sentence from the pet's perspective."
        )
        return _SYSTEM_PET, user

    if evt.name == BodyEventName.OWNER_PING:
        user = (
            f"Pet name: {bi.pet_name}. {_body_line(bi)}.\n"
            f"The owner called your attention (double-click).\n"
            f"Emotion hint: {bi.emotion_hint}. {_drives_line(bi.drives)}.\n"
            "Reply with exactly one short natural Chinese sentence from the pet's perspective."
        )
        return _SYSTEM_PET, user

    if evt.name == BodyEventName.WALL_HIT:
        intensity = float(p.get("intensity", 0))
        user = (
            f"Pet name: {bi.pet_name}. {_body_line(bi)}.\n"
            f"You just slammed into a wall. Impact intensity: {intensity:.1f}/40.\n"
            f"Emotion hint: {bi.emotion_hint}.\n"
            "Reply with exactly one short natural Chinese sentence from the pet's perspective."
        )
        return _SYSTEM_PET, user

    if evt.name == BodyEventName.GROUND_HIT:
        intensity = float(p.get("intensity", 0))
        user = (
            f"Pet name: {bi.pet_name}. {_body_line(bi)}.\n"
            f"You just hit the ground hard. Impact intensity: {intensity:.1f}/40.\n"
            f"Emotion hint: {bi.emotion_hint}.\n"
            "Reply with exactly one short natural Chinese sentence from the pet's perspective."
        )
        return _SYSTEM_PET, user

    if evt.name == BodyEventName.NEEDS_UPDATE:
        need = str(p.get("need", ""))
        user = (
            f"Pet name: {bi.pet_name}. {_body_line(bi)}.\n"
            f"You feel: {need}. {_drives_line(bi.drives)}.\n"
            f"Emotion hint: {bi.emotion_hint}.\n"
            "Reply with exactly one short natural Chinese sentence from the pet's perspective."
        )
        return _SYSTEM_PET, user

    return None


def autonomy_prompt(bi: BrainInput, motive: str) -> tuple[str, str]:
    """Returns (system, user) for a spontaneous autonomous action."""
    mem = f"\nRelevant memory:\n{bi.memory_context}" if bi.memory_context else ""
    user = (
        f"Pet name: {bi.pet_name}\n"
        f"{_body_line(bi)}\n"
        f"{_drives_line(bi.drives)}\n"
        f"Dominant motive: {motive}\n"
        f"Emotion hint: {bi.emotion_hint}\n"
        f"The pet is idle and wants to do something small and natural on its own.\n"
        f"{_ACTION_SCHEMA}\n"
        f"{_ACTION_RULES}"
        f"{mem}\n"
        "Choose a subtle, believable voluntary action matching the motive. "
        "If no action is appropriate, use intent 'none' and leave reply empty."
    )
    return _SYSTEM_ACTION, user


def memory_extract_prompt(
    user_text: str,
    pet_reply: str,
    existing_index: str,
) -> tuple[str, str]:
    """Returns (system, user) for the memory extraction call."""
    system = (
        "You are a memory manager for a desktop pet AI. "
        "You read a conversation turn and decide whether to store a new long-term memory."
    )
    user = (
        "Conversation turn:\n"
        f"  Owner: {user_text}\n"
        f"  Pet: {pet_reply}\n\n"
        "Existing memory index (do not duplicate):\n"
        f"{existing_index or 'None'}\n\n"
        "If there is something worth remembering long-term (owner name, preference, "
        "important event, or relationship fact), respond with JSON:\n"
        '{"store": true, "type": "identity|preferences|episodes|behavior", '
        '"title": "<short title>", "summary": "<one sentence>"}\n'
        "If nothing is worth storing, respond with:\n"
        '{"store": false}\n'
        "Do NOT duplicate information already in the index."
    )
    return system, user
