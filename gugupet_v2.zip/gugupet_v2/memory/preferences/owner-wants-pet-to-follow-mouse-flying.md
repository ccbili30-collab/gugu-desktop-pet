---
type: preferences
description: Owner wants pet to follow mouse flying
---

# Owner wants pet to follow mouse flying

- The owner instructed the desktop pet to fly following their mouse cursor.
