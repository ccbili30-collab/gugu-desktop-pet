---
type: preferences
description: Interaction preferences.
---

# Interaction Preferences

暂无。
