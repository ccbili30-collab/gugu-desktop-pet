---
type: preferences
description: Owner wants pet to tell a long story
---

# Owner wants pet to tell a long story

- The owner asked the desktop pet to tell a long story.
