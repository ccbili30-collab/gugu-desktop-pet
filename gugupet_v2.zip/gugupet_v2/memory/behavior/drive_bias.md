---
type: behavior
description: Long-term behavior tendencies.
---

# Drive Bias

暂无。
