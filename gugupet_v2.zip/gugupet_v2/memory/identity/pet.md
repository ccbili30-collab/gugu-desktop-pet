---
type: identity
description: Pet identity.
---

# Pet

咕咕是一只桌面鸽子宠物。
