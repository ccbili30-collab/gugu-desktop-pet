# Memory Index
- [identity] owner -> identity\owner.md
- [episodes] test episode -> episodes\2026-04-09-test-episode.md
- [identity] 桌面宠物的自身身份 -> identity\桌面宠物的自身身份.md
- [preferences] Owner wants pet to follow mouse flying -> preferences\owner-wants-pet-to-follow-mouse-flying.md
- [preferences] Owner wants pet to tell a long story -> preferences\owner-wants-pet-to-tell-a-long-story.md
- [identity] 桌面宠物的自身能力 -> identity\桌面宠物的自身能力.md
